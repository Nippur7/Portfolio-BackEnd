package Cv_Dynamic.Backend_arg_prog;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BackendArgProgApplication {

	public static void main(String[] args) {
		SpringApplication.run(BackendArgProgApplication.class, args);
	}

}
