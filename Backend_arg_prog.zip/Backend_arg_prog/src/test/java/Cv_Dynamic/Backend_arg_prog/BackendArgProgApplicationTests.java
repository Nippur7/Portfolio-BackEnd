package Cv_Dynamic.Backend_arg_prog;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BackendArgProgApplicationTests {

	@Test
	void contextLoads() {
	}

}
