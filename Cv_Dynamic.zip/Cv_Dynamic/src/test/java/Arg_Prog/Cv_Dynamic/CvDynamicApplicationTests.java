package Arg_Prog.Cv_Dynamic;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CvDynamicApplicationTests {

	@Test
	void contextLoads() {
	}

}
