package Arg_Prog.Cv_Dynamic;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CvDynamicApplication {

	public static void main(String[] args) {
		SpringApplication.run(CvDynamicApplication.class, args);
	}

}
