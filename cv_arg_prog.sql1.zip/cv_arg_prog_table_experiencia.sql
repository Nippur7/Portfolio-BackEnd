
-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `experiencia`
--

DROP TABLE IF EXISTS `experiencia`;
CREATE TABLE IF NOT EXISTS `experiencia` (
  `idexperiencia` int(11) NOT NULL AUTO_INCREMENT,
  `imagen` mediumblob NOT NULL,
  `lugar` varchar(30) NOT NULL,
  `inicio` date NOT NULL,
  `fin` date NOT NULL,
  `iddetalles` int(11) NOT NULL,
  `tipo` int(11) NOT NULL,
  `obs` varchar(30) NOT NULL,
  `iduser` int(11) DEFAULT NULL,
  `modificado` datetime DEFAULT NULL,
  PRIMARY KEY (`idexperiencia`),
  KEY `delete_exp` (`iduser`),
  KEY `delete_det` (`iddetalles`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Disparadores `experiencia`
--
DROP TRIGGER IF EXISTS `experiencia_BEFORE_INSERT`;
DELIMITER $$
CREATE TRIGGER `experiencia_BEFORE_INSERT` BEFORE INSERT ON `experiencia` FOR EACH ROW BEGIN
	set NEW.modificado = CURRENT_TIMESTAMP;
END
$$
DELIMITER ;
