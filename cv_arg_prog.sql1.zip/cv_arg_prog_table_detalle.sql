
-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `detalle`
--

DROP TABLE IF EXISTS `detalle`;
CREATE TABLE IF NOT EXISTS `detalle` (
  `iddetalles` int(11) NOT NULL AUTO_INCREMENT,
  `puesto` varchar(30) NOT NULL,
  `descripción` varchar(80) NOT NULL,
  `obs` varchar(20) NOT NULL,
  `iduser` int(11) DEFAULT NULL,
  PRIMARY KEY (`iddetalles`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
