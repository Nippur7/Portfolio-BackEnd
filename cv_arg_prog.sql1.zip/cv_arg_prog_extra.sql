
--
-- Restricciones para tablas volcadas
--

--
-- Filtros para la tabla `experiencia`
--
ALTER TABLE `experiencia`
  ADD CONSTRAINT `delete_det` FOREIGN KEY (`iddetalles`) REFERENCES `detalle` (`iddetalles`),
  ADD CONSTRAINT `delete_exp` FOREIGN KEY (`iduser`) REFERENCES `usuario` (`idusuario`);

--
-- Filtros para la tabla `skill`
--
ALTER TABLE `skill`
  ADD CONSTRAINT `delete_skill` FOREIGN KEY (`iduser`) REFERENCES `usuario` (`idusuario`);
