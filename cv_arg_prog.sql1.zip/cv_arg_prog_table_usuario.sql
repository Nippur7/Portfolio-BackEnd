
-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `usuario`
--

DROP TABLE IF EXISTS `usuario`;
CREATE TABLE IF NOT EXISTS `usuario` (
  `idusuario` int(11) NOT NULL AUTO_INCREMENT,
  `apellido` varchar(30) NOT NULL,
  `nombre` varchar(30) NOT NULL,
  `email` varchar(60) NOT NULL,
  `password` varchar(50) NOT NULL,
  `ingreso` date NOT NULL,
  `aboutme` varchar(45) DEFAULT NULL,
  `picture` mediumblob DEFAULT NULL,
  PRIMARY KEY (`idusuario`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Disparadores `usuario`
--
DROP TRIGGER IF EXISTS `usuario_BEFORE_UPDATE`;
DELIMITER $$
CREATE TRIGGER `usuario_BEFORE_UPDATE` BEFORE INSERT ON `usuario` FOR EACH ROW BEGIN	    
		set NEW.ingreso = CURRENT_TIMESTAMP;
END
$$
DELIMITER ;
