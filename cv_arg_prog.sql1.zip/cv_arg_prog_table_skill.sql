
-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `skill`
--

DROP TABLE IF EXISTS `skill`;
CREATE TABLE IF NOT EXISTS `skill` (
  `idskill` int(11) NOT NULL AUTO_INCREMENT,
  `detalle` varchar(30) NOT NULL,
  `porcentaje` float NOT NULL,
  `experiencia` int(11) NOT NULL,
  `modificado` date NOT NULL,
  `iduser` int(11) NOT NULL,
  PRIMARY KEY (`idskill`),
  KEY `delete_skill` (`iduser`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Disparadores `skill`
--
DROP TRIGGER IF EXISTS `skill_BEFORE_INSERT`;
DELIMITER $$
CREATE TRIGGER `skill_BEFORE_INSERT` BEFORE INSERT ON `skill` FOR EACH ROW BEGIN
	set NEW.modificado = CURRENT_TIMESTAMP;
END
$$
DELIMITER ;
