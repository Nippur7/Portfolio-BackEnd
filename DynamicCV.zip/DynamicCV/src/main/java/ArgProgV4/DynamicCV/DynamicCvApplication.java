package ArgProgV4.DynamicCV;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DynamicCvApplication {

	public static void main(String[] args) {
		SpringApplication.run(DynamicCvApplication.class, args);
	}

}
